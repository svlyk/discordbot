const Discord = require('discord.js');
const client = new Discord.Client();
const TOKEN = 'NTU0NDM0ODgwOTAyMTM1ODM4.D2dExw.wBdgGWQe_ybY7yyGzxou8RJxt4c'

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

client.on('message', async message => {
  if (message.author == '<@472141928578940958>'){ //WaifuBot
		if (message.embeds[0]==null) {
			return;
		} else if(message.embeds[0].description.includes('A waifu/husbando appeared'))  {
			message.channel.send('<@&554540123132395522>');
		} else {
			return;
		}
  } else if(message.author =='<@365975655608745985>') {
		if (message.embeds[0]==null) {
			return;
		} else if(message.embeds[0].description.includes('Guess the pok'))  {
			message.channel.send('<@&554543102145069068>');
		} else {
			return;
		}
  } else {
		return;
  }
});
client.login(TOKEN);